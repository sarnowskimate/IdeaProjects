package com.company;

public class Wykaz {
    ListaDanych listaDanych;

    public Wykaz(ListaDanych listaDanych) {
        this.listaDanych = listaDanych;
    }

    public String tabela() {
        String s = listaDanych.naglowekZestawienia();
        s += listaDanych.zestawienieList();
        s += listaDanych.trescDodInfTekst();
        return s;
    }






}
