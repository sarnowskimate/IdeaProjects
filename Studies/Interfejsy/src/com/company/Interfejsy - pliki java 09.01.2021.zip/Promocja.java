package com.company;

public class Promocja implements ListaDanych {
    String informacjaTekstowa;
    Towar[] wykazTowarow;

    public Promocja(String informacjaTekstowa, Towar[] wykazTowarow) {
        this.informacjaTekstowa = informacjaTekstowa;
        this.wykazTowarow = wykazTowarow;
    }

    @Override
    public String naglowekZestawienia() {
        return "L.p. " + informacjaTekstowa + "\n";
    }

    @Override
    public String zestawienieList() {
        String s = "";
        for (int i = 0; i < wykazTowarow.length; i++) {
            s = s + (i + 1) + ". " + wykazTowarow[i] + "\n";
        }
        return s;
    }

    @Override
    public String trescDodInfTekst() {
        double sredniRabat = 0;
        for (int i = 0; i < wykazTowarow.length; i++) {
            sredniRabat += wykazTowarow[i].cenaPodstawowa - wykazTowarow[i].cenaPromocyjna;
        }
        sredniRabat *= 100;
        return "Sredni rabat wynosi " + sredniRabat + "zl";
    };
}
