package com.company;

public interface ListaDanych { // jak Protocol
    public String naglowekZestawienia();
    public String zestawienieList();
    public String trescDodInfTekst();

}
