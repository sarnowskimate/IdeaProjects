package com.company;

public class Osoba {
    String imie;
    String nazwisko;
    String pesel;
    double kwotaWplaty;

    public Osoba(String imie, String nazwisko, String pesel, double kwotaWplaty) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.pesel = pesel;
        this.kwotaWplaty = kwotaWplaty;
    }

    public String toString() {
        return imie + " " + nazwisko + ", " + pesel + ", " + kwotaWplaty + "zl";
    }
}
