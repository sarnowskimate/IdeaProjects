package com.company;

public class Wycieczka implements ListaDanych {
    String programWycieczki;
    Osoba[] wykazUczestnikow;

    public Wycieczka(String programWycieczki, Osoba[] wykazUczestnikow) {
        this.programWycieczki = programWycieczki;
        this.wykazUczestnikow = wykazUczestnikow;
    }

    @Override
    public String naglowekZestawienia() {
        return "L.p. " + programWycieczki + "\n";
    }

    @Override
    public String zestawienieList() {
        String s = "";
        for (int i = 0; i < wykazUczestnikow.length; i++) {
            s = s + (i + 1) + ". " + wykazUczestnikow[i] + "\n";
        }
        return s;
    }

    @Override
    public String trescDodInfTekst() {
        double sumaWplat = 0;
        for (int i = 0; i < wykazUczestnikow.length; i++) {
            sumaWplat += wykazUczestnikow[i].kwotaWplaty;
        }
        return "Suma wplat wynosi " + sumaWplat + "zl";
    };
}
