package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here

        Osoba[] osoby = new Osoba[4];
        osoby[0] = new Osoba("Mateusz", "Sarnowski", "93030803578", 100);
        osoby[1] = new Osoba("Monika", "Kwiatkowska", "95021099999", 90);
        osoby[2] = new Osoba("Katarzyna", "Sarnowska", "69052699999", 200);
        osoby[3] = new Osoba("Blazej", "Ochocki", "95092299999", 68);

        Towar[] towary = new Towar[5];
        towary[0] = new Towar("Laptop", 4000, 3000);
        towary[1] = new Towar("Myszka", 300, 200);
        towary[2] = new Towar("Monitor", 2000, 1600);
        towary[3] = new Towar("Drukarka", 700, 650);
        towary[4] = new Towar("Telefon", 1200, 990);

        // opcja 1
        Wycieczka w1 = new Wycieczka("Wycieczka w gory.", osoby);
        Promocja p1 = new Promocja("Przecena swiateczna.",towary);

        Wykaz wyk1 = new Wykaz(w1);
        Wykaz wyk2 = new Wykaz(p1);

        System.out.println(wyk1.tabela());
        System.out.println(wyk2.tabela());


        // opcja 2
        ListaDanych ld1 = new Wycieczka("Wycieczka w gory.", osoby);
        ListaDanych ld2 = new Promocja("Przecena swiateczna.",towary);

        Wykaz ww1 = new Wykaz(ld1);
        Wykaz ww2 = new Wykaz(ld2);

        System.out.println(ww1.tabela());
        System.out.println(ww2.tabela());


    }
}
