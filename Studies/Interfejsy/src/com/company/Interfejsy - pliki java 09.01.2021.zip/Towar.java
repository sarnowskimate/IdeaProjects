package com.company;

public class Towar {
    String nazwa;
    double cenaPodstawowa;
    double cenaPromocyjna;

    public Towar(String nazwa, double cenaPodstawowa, double cenaPromocyjna) {
        this.nazwa = nazwa;
        this.cenaPodstawowa = cenaPodstawowa;
        this.cenaPromocyjna = cenaPromocyjna;
    }

    public String toString() {
        return nazwa + ", prod. przeceniony z " + cenaPodstawowa + "zl na " + cenaPromocyjna + "zl";
    }
}
