package com.company;

public interface DataList { // like Protocol
    public String title();
    public String[] listView();
    public String additionalInfo();

}
